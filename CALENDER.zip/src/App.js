import logo from './logo.svg';
import Box from './Box.js';
import Daybox from './Daybox.js';
import Calander from './Calander';

function App() {
  return (
    <div className="App">
       <center>
       <Calander/>
       </center>
    </div>
  );
}

export default App;
